# Les données

Placez le(s) fichier(s) de données dans ce dossier.

Ensuite, incluez un dictionnaire des données (variables et leurs descriptions) pour vos fichiers de données en utilisant le format suivant.


## nom du fichier de données

# Covid19.csv

Entity: Pays
Day: Date
Total confirmed cases of COVID-19: Cas de covid-19 par jour

# daily-new-confirmed-covid-19-deaths-per-million-people.csv

Entity: Pays
Day: Date
Daily new confirmed deaths due to COVID-19 per million people (rolling 7-day average, right-aligned): Nombre de décès
par jour

# vaccinationcanada.csv

week_end: Date
prfname: Nom de la province
numtot_alatleast1dose: Nombre total de personnes vaccinées par province par date
** J'ai enlevé toutes les autres variables
