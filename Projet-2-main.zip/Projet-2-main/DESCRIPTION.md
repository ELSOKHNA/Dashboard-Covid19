# DESCRIPTION DU PROJET

## Nom de l'équipe
Equipe 2


## Projet choisi
Dashboard 



## Objectifs
Étude portant sur l'évolution de la pandémie Covid 19 dans le temps a travaers le mone !
Dashboard adapté au grand public !

## Données

- [Our World in Data](https://ourworldindata.org/)
- [Santé InfoBase Canada](https://sante-infobase.canada.ca/)


## Livrables attendus
document Rmd : projet_test.Rmd

